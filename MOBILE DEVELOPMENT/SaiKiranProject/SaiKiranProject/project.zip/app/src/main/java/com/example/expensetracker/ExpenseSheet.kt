package com.example.expensetracker

class ExpenseSheet(
    val id: Long,
    val month: String,
    val year: Int,
    var income: Double = 0.0,
    val expenses: MutableList<Expense> = mutableListOf()
)