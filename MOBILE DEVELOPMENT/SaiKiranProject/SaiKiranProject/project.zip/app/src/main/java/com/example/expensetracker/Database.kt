package com.example.expensetrapackage

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import com.example.expensetracker.Expense
import com.example.expensetracker.ExpenseSheet
import java.text.SimpleDateFormat
import java.util.*

class Database(context: Context) : SQLiteOpenHelper(context, "ExpenseDB", null, 1) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE sheets (id INTEGER PRIMARY KEY AUTOINCREMENT, month TEXT, year INTEGER, income REAL)")
        db.execSQL("CREATE TABLE expenses (id INTEGER PRIMARY KEY AUTOINCREMENT, sheet_id INTEGER, name TEXT, amount REAL, date TEXT)")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS sheets")
        db.execSQL("DROP TABLE IF EXISTS expenses")
        onCreate(db)
    }

    fun AddSheet(month: String, year: Int, income: Double): Long {
        val db = writableDatabase
        val values = ContentValues()
        values.put("month", month)
        values.put("year", year)
        values.put("income", income)
        return db.insert("sheets", null, values)
    }

    fun FetchAllSheets(): List<ExpenseSheet> {
        val list = mutableListOf<ExpenseSheet>()
        val db = readableDatabase
        val cursor = db.rawQuery("SELECT * FROM sheets", null)

        if (cursor.moveToFirst()) {
            do {
                val id = cursor.getLong(0)
                val month = cursor.getString(1)
                val year = cursor.getInt(2)
                val income = cursor.getDouble(3)
                val expenses = FetchExpensesForSheet(id)
                list.add(ExpenseSheet(id, month, year, income, expenses))
            } while (cursor.moveToNext())
        }
        cursor.close()
        return list
    }

    fun UpdateSheet(id: Long, month: String, year: Int, income: Double) {
        val db = writableDatabase
        val values = ContentValues()
        values.put("month", month)
        values.put("year", year)
        values.put("income", income)
        db.update("sheets", values, "id = ?", arrayOf(id.toString()))
    }

    fun DeleteSheet(id: Long) {
        val db = writableDatabase
        db.delete("expenses", "sheet_id = ?", arrayOf(id.toString()))
        db.delete("sheets", "id = ?", arrayOf(id.toString()))
    }

    fun AddExpense(sheetId: Long, name: String, amount: Double, date: String): Long {
        val db = writableDatabase
        val values = ContentValues()
        values.put("sheet_id", sheetId)
        values.put("name", name)
        values.put("amount", amount)
        values.put("date", date)
        return db.insert("expenses", null, values)
    }

    fun FetchExpensesForSheet(sheetId: Long): MutableList<Expense> {
        val list = mutableListOf<Expense>()

        readableDatabase.rawQuery(
            "SELECT * FROM expenses WHERE sheet_id = ?",
            arrayOf(sheetId.toString())
        ).use { cursor ->
            while (cursor.moveToNext()) {
                list.add(
                    Expense(
                        id = cursor.getLong(0),
                        name = cursor.getString(2),
                        amount = cursor.getDouble(3),
                        date = cursor.getString(4)
                    )
                )
            }
        }

        return list
    }
    fun UpdateExpense(id: Long, name: String, amount: Double, date: String) {
        val db = writableDatabase
        val values = ContentValues()
        values.put("name", name)
        values.put("amount", amount)
        values.put("date", date)
        db.update("expenses", values, "id = ?", arrayOf(id.toString()))
    }

    fun DeleteExpense(id: Long) {
        val db = writableDatabase
        db.delete("expenses", "id = ?", arrayOf(id.toString()))
    }
}
