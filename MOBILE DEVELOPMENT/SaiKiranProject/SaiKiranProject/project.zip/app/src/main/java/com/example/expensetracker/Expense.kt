package com.example.expensetracker

class Expense(
    val id: Long,
    val name: String,
    val amount: Double,
    val date: String
)