package com.example.expensetracker

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.expensetrapackage.Database
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale



//this function is use to create new sheets and display sheets which has been created already
//also user can navigate to graph page by pressing view graph button
@Composable
fun ExpenseTrack(db: Database) {

    var selectedSheet by remember { mutableStateOf<ExpenseSheet?>(null) }
    var showGraph by remember { mutableStateOf(false) }
    var showDialog by remember { mutableStateOf(false) }
    var month by remember { mutableStateOf("") }
    var year by remember { mutableStateOf("") }
    var pageRefresh by remember { mutableStateOf(0) }
    var sheets by remember { mutableStateOf(db.FetchAllSheets()) }

    LaunchedEffect(pageRefresh) {
        sheets = db.FetchAllSheets()
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Spacer(modifier = Modifier.height(50.dp))

        Text(
            text = "Expense Tracker App",
            style = MaterialTheme.typography.displaySmall,
            color = Color(0xFF01C194),
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(16.dp))

        if (!showGraph && selectedSheet == null) {
            Button(
                onClick = {
                    month = FetchCurrentMonth()
                    year = FetchCurrentYear().toString()
                    showDialog = true
                },
                modifier = Modifier.fillMaxWidth(),
                shape = RectangleShape,
                contentPadding = PaddingValues(16.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFF01C194),
                    contentColor = Color.White
                )
            ) {
                Text("Create New Sheet", fontSize = 18.sp)
            }

            Spacer(modifier = Modifier.height(8.dp))

            Button(
                onClick = { showGraph = true },
                modifier = Modifier.fillMaxWidth(),
                contentPadding = PaddingValues(16.dp),
                shape = RectangleShape
            ) {
                Text("View Graph", fontSize = 18.sp)
            }

            Spacer(modifier = Modifier.height(16.dp))

            if (sheets.isEmpty()) {
                Text("No sheets yet")
            } else {
                LazyColumn {
                    items(sheets) { sheet ->
                        NewSheet(
                            sheet = sheet,
                            db = db,
                            onClick = { selectedSheet = sheet },
                            onRefresh = { pageRefresh++ }
                        )
                    }
                }
            }
        }

        if (selectedSheet != null) {
            SheetDetails(selectedSheet!!, db) {
                selectedSheet = null
                pageRefresh++
            }
        }

        if (showGraph) {
            ViewGraph(sheets)
            Spacer(modifier = Modifier.height(16.dp))
            Button(
                onClick = { showGraph = false },
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFF01C194),
                    contentColor = Color.White
                ),
                shape = RectangleShape
            ) {
                Text("Back")
            }
        }
    }

    if (showDialog) {
        AlertDialog(
            onDismissRequest = { showDialog = false },
            title = { Text("New Sheet") },
            text = {
                Column {
                    TextField(
                        value = month,
                        onValueChange = { month = it },
                        label = { Text("Month") }
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    TextField(
                        value = year,
                        onValueChange = { year = it },
                        label = { Text("Year") }
                    )
                }
            },
            shape = RectangleShape,
            confirmButton = {
                Button(
                    onClick = {
                        if (month.isNotEmpty() && year.isNotEmpty()) {
                            db.AddSheet(month, year.toIntOrNull() ?: FetchCurrentYear(), 0.0)
                            month = ""
                            year = ""
                            showDialog = false
                            pageRefresh++
                        }
                    },
                    shape = RectangleShape
                ) {
                    Text("Create")
                }
            },
            dismissButton = {
                Button(
                    onClick = { showDialog = false },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF01C194),
                        contentColor = Color.White
                    ),
                    shape = RectangleShape
                ) {
                    Text("Cancel")
                }
            }
        )
    }
}

//user can create new sheets and can edit those sheet like month and a year
@Composable
fun NewSheet(sheet: ExpenseSheet, db: Database, onClick: () -> Unit, onRefresh: () -> Unit) {
    var showEditDialog by remember { mutableStateOf(false) }
    var showDeleteDialog by remember { mutableStateOf(false) }

    val total = sheet.expenses.sumOf { it.amount }
    val balance = sheet.income - total

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(8.dp)
            .clickable { onClick() },
        shape = RectangleShape
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "${sheet.month} ${sheet.year}",
                style = MaterialTheme.typography.titleLarge
            )
            Text("Income: $${sheet.income}")
            Text("Expenses: $${total}")
            Text(
                text = if (balance >= 0) "Surplus: $${balance}" else "Deficit: $${-balance}",
                color = if (balance >= 0) Color.Green else Color.Red
            )

            Row {
                Button(
                    onClick = { showEditDialog = true },
                    shape = RectangleShape,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF01C194),
                        contentColor = Color.White
                    )
                ) {
                    Text("Edit")
                }
                Spacer(modifier = Modifier.width(8.dp))
                Button(onClick = { showDeleteDialog = true }, shape = RectangleShape) {
                    Text("Delete")
                }
            }
        }
    }

    if (showEditDialog) {
        var editMonth by remember { mutableStateOf(sheet.month) }
        var editYear by remember { mutableStateOf(sheet.year.toString()) }

        AlertDialog(
            onDismissRequest = { showEditDialog = false },
            shape = RectangleShape,
            title = { Text("Edit Sheet") },
            text = {
                Column {
                    TextField(
                        value = editMonth,
                        onValueChange = { editMonth = it },
                        label = { Text("Month") }
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    TextField(
                        value = editYear,
                        onValueChange = { editYear = it },
                        label = { Text("Year") }
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        db.UpdateSheet(sheet.id, editMonth, editYear.toIntOrNull() ?: sheet.year, sheet.income)
                        showEditDialog = false
                        onRefresh()
                    },
                    shape = RectangleShape
                ) {
                    Text("Save")
                }
            },
            dismissButton = {
                Button(
                    onClick = { showEditDialog = false },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF01C194),
                        contentColor = Color.White
                    ),
                    shape = RectangleShape
                ) {
                    Text("Cancel")
                }
            }
        )
    }

    if (showDeleteDialog) {
        AlertDialog(
            onDismissRequest = { showDeleteDialog = false },
            shape = RectangleShape,
            title = { Text("Delete Sheet") },
            text = { Text("Are you sure you want to delete this sheet?") },
            confirmButton = {
                Button(
                    onClick = {
                        db.DeleteSheet(sheet.id)
                        showDeleteDialog = false
                        onRefresh()
                    },
                    shape = RectangleShape
                ) {
                    Text("Delete")
                }
            },
            dismissButton = {
                Button(
                    onClick = { showDeleteDialog = false },
                    shape = RectangleShape,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF01C194),
                        contentColor = Color.White
                    )
                ) {
                    Text("Cancel")
                }
            }
        )
    }
}

//Inside of new sheet user can add income and expenses where user can define date, expense name,
// expense amount to create expense sheet by following expense sheet function
@Composable
fun SheetDetails(sheet: ExpenseSheet, db: Database, onBack: () -> Unit) {
    var showIncomeDialog by remember { mutableStateOf(false) }
    var showExpenseDialog by remember { mutableStateOf(false) }
    var incomeText by remember { mutableStateOf(sheet.income.toString()) }
    var expenseName by remember { mutableStateOf("") }
    var expenseAmount by remember { mutableStateOf("") }
    var expenseDate by remember { mutableStateOf(FetchCurrentDate()) }
    var refresh by remember { mutableStateOf(0) }

    val expenses = remember(refresh) { db.FetchExpensesForSheet(sheet.id) }
    val total = expenses.sumOf { it.amount }
    val balance = sheet.income - total

    Column {
        Text(
            text = "${sheet.month} ${sheet.year}",
            style = MaterialTheme.typography.headlineMedium
        )

        Spacer(modifier = Modifier.height(16.dp))

        Card(modifier = Modifier.fillMaxWidth(), shape = RectangleShape) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("Income: $${sheet.income}")
                Spacer(modifier = Modifier.height(8.dp))
                Column( Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                Button(
                    onClick = { showIncomeDialog = true },
                    modifier = Modifier.width(200.dp),
                    shape = RectangleShape,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF01C194),
                        contentColor = Color.White
                    )
                ) {
                    Text("Edit Income")
                }}
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Card(modifier = Modifier.fillMaxWidth(), shape = RectangleShape) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("Total Expenses: $${total}")
                Text(
                    text = if (balance >= 0) "Surplus: $${balance}" else "Deficit: $${-balance}",
                    color = if (balance >= 0) Color.Green else Color.Red
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Button(
                onClick = {
                    expenseDate = FetchCurrentDate()
                    showExpenseDialog = true
                },
                modifier = Modifier.width(200.dp),
                shape = RectangleShape
            ) {
                Text("Add Expense")
            }
        }


        Spacer(modifier = Modifier.height(16.dp))

        if (expenses.isEmpty()) {
            Text("No expenses")
        } else {
            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
            ) {
                items(expenses) { expense ->
                    ExpenseSheet(expense, db) {
                        refresh++
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))
        Button(onClick = onBack, shape = RectangleShape,  colors = ButtonDefaults.buttonColors(
            containerColor = Color(0xFF01C194),
            contentColor = Color.White
        )) {
            Text("Back")
        }
    }

    if (showIncomeDialog) {
        AlertDialog(
            onDismissRequest = { showIncomeDialog = false },
            title = { Text("Edit Income") },
            shape = RectangleShape,
            text = {
                TextField(
                    value = incomeText,
                    onValueChange = { incomeText = it },
                    label = { Text("Income Amount") }
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        val newIncome = incomeText.toDoubleOrNull() ?: 0.0
                        db.UpdateSheet(sheet.id, sheet.month, sheet.year, newIncome)
                        sheet.income = newIncome
                        showIncomeDialog = false
                        refresh++
                    },
                    shape = RectangleShape
                ) {
                    Text("Save")
                }
            },
            dismissButton = {
                Button(onClick = { showIncomeDialog = false }, shape = RectangleShape,  colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFF01C194),
                    contentColor = Color.White
                )) {
                    Text("Cancel")
                }
            }
        )
    }

    if (showExpenseDialog) {
        AlertDialog(
            onDismissRequest = { showExpenseDialog = false },
            title = { Text("Add Expense") },
            shape = RectangleShape,
            text = {
                Column {
                    TextField(
                        value = expenseName,
                        onValueChange = { expenseName = it },
                        label = { Text("Expense Name") }
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    TextField(
                        value = expenseAmount,
                        onValueChange = { expenseAmount = it },
                        label = { Text("Amount") }
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    TextField(
                        value = expenseDate,
                        onValueChange = { expenseDate = it },
                        label = { Text("Date (YYYY-MM-DD)") }
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (expenseName.isNotEmpty() && expenseAmount.isNotEmpty()) {
                            db.AddExpense(sheet.id, expenseName, expenseAmount.toDoubleOrNull() ?: 0.0, expenseDate)
                            expenseName = ""
                            expenseAmount = ""
                            showExpenseDialog = false
                            refresh++
                        }
                    },
                    shape = RectangleShape,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF01C194),
                        contentColor = Color.White
                    )
                ) {
                    Text("Add")
                }
            },
            dismissButton = {
                Button(onClick = { showExpenseDialog = false }, shape = RectangleShape) {
                    Text("Cancel")
                }
            }
        )
    }
}

// this is to edit and delete created expense sheet
@Composable
fun ExpenseSheet(expense: Expense, db: Database, onUpdate: () -> Unit) {
    var showEditDialog by remember { mutableStateOf(false) }
    var showDeleteDialog by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(8.dp),
        shape = RectangleShape
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(expense.name, style = MaterialTheme.typography.titleMedium)
                    Text(expense.date, style = MaterialTheme.typography.bodySmall)
                }
                Text("$${expense.amount}")
            }

            Row {
                Button(onClick = { showEditDialog = true }, colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFF01C194),
                    contentColor = Color.White
                ),
                    shape = RectangleShape) {
                    Text("Edit")
                }
                Spacer(modifier = Modifier.width(8.dp))
                Button(onClick = { showDeleteDialog = true }, shape = RectangleShape) {
                    Text("Delete")
                }
            }
        }
    }

    if (showEditDialog) {
        var editName by remember { mutableStateOf(expense.name) }
        var editAmount by remember { mutableStateOf(expense.amount.toString()) }
        var editDate by remember { mutableStateOf(expense.date) }

        AlertDialog(
            onDismissRequest = { showEditDialog = false },
            title = { Text("Edit Expense") },
            shape = RectangleShape,
            text = {
                Column {
                    TextField(
                        value = editName,
                        onValueChange = { editName = it },
                        label = { Text("Name") }
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    TextField(
                        value = editAmount,
                        onValueChange = { editAmount = it },
                        label = { Text("Amount") }
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    TextField(
                        value = editDate,
                        onValueChange = { editDate = it },
                        label = { Text("Date") }
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        db.UpdateExpense(expense.id, editName, editAmount.toDoubleOrNull() ?: 0.0, editDate)
                        showEditDialog = false
                        onUpdate()
                    },
                    shape = RectangleShape,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF01C194),
                        contentColor = Color.White
                    )
                ) {
                    Text("Save")
                }
            },
            dismissButton = {
                Button(onClick = { showEditDialog = false }, shape = RectangleShape,) {
                    Text("Cancel")
                }
            }
        )
    }

    if (showDeleteDialog) {
        AlertDialog(
            shape = RectangleShape,
            onDismissRequest = { showDeleteDialog = false },
            title = { Text("Delete Expense") },
            text = { Text("Are you sure?") },
            confirmButton = {
                Button(
                    onClick = {
                        db.DeleteExpense(expense.id)
                        showDeleteDialog = false
                        onUpdate()
                    },
                    shape = RectangleShape,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF01C194),
                        contentColor = Color.White
                    )
                ) {
                    Text("Delete")
                }
            },
            dismissButton = {
                Button(onClick = { showDeleteDialog = false }, shape = RectangleShape) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
fun ViewGraph(allSheets: List<ExpenseSheet>) {
    var startPosition by remember { mutableStateOf(0) }

    var sheetsToShow = listOf<ExpenseSheet>()
    if (allSheets.size > 4) {
        var endPosition = startPosition + 4
        if (endPosition > allSheets.size) {
            endPosition = allSheets.size
        }
        sheetsToShow = allSheets.subList(startPosition, endPosition)
    } else {
        sheetsToShow = allSheets
    }

    Column {
        Text(
            text = "Income/Expenses",
            style = MaterialTheme.typography.headlineLarge
        )

        Spacer(modifier = Modifier.height(16.dp))

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(1f)
                .pointerInput(Unit) {
                    detectDragGestures { _, drag ->
                        if (drag.x > 50) {
                            if (startPosition > 0) {
                                startPosition = startPosition - 1
                            }
                        }
                        if (drag.x < -50) {
                            if (startPosition + 4 < allSheets.size) {
                                startPosition = startPosition + 1
                            }
                        }
                    }
                }
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val width = size.width
                val height = size.height
                val padding = 80f

                drawLine(Color.Black, Offset(padding, padding), Offset(padding, height - padding), 3f)
                drawLine(Color.Black, Offset(padding, height - padding), Offset(width - padding, height - padding), 3f)

                if (sheetsToShow.isNotEmpty()) {
                    var maxAmount = 0.0
                    for (sheet in sheetsToShow) {
                        if (sheet.income > maxAmount) {
                            maxAmount = sheet.income
                        }
                        var totalExpenses = 0.0
                        for (expense in sheet.expenses) {
                            totalExpenses = totalExpenses + expense.amount
                        }
                        if (totalExpenses > maxAmount) {
                            maxAmount = totalExpenses
                        }
                    }

                    var spacing = (width - 2 * padding) / 3
                    if (sheetsToShow.size > 1) {
                        spacing = (width - 2 * padding) / (sheetsToShow.size - 1)
                    }

                    var heightScale = 1.0
                    if (maxAmount > 0) {
                        heightScale = (height - 2 * padding) / maxAmount
                    }

                    var incomeX = mutableListOf<Float>()
                    var incomeY = mutableListOf<Float>()
                    var expenseX = mutableListOf<Float>()
                    var expenseY = mutableListOf<Float>()

                    var index = 0
                    for (sheet in sheetsToShow) {
                        val xPosition = padding + index * spacing

                        val incomeHeight = (sheet.income * heightScale).toFloat()
                        val incomeYPosition = height - padding - incomeHeight

                        var expenseTotal = 0.0
                        for (expense in sheet.expenses) {
                            expenseTotal = expenseTotal + expense.amount
                        }
                        val expenseHeight = (expenseTotal * heightScale).toFloat()
                        val expenseYPosition = height - padding - expenseHeight

                        incomeX.add(xPosition)
                        incomeY.add(incomeYPosition)
                        expenseX.add(xPosition)
                        expenseY.add(expenseYPosition)

                        drawCircle(Color.Blue, 8f, Offset(xPosition, incomeYPosition))
                        drawCircle(Color.Red, 8f, Offset(xPosition, expenseYPosition))

                        index = index + 1
                    }

                    var i = 0
                    while (i < incomeX.size - 1) {
                        drawLine(Color.Blue, Offset(incomeX[i], incomeY[i]), Offset(incomeX[i + 1], incomeY[i + 1]), 4f)
                        i = i + 1
                    }

                    var j = 0
                    while (j < expenseX.size - 1) {
                        drawLine(Color.Red, Offset(expenseX[j], expenseY[j]), Offset(expenseX[j + 1], expenseY[j + 1]), 4f)
                        j = j + 1
                    }
                }
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Center
        ) {
            Box(modifier = Modifier.size(20.dp).padding(4.dp)) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    drawCircle(Color.Blue)
                }
            }
            Text(" = Income    ")
            Box(modifier = Modifier.size(20.dp).padding(4.dp)) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    drawCircle(Color.Red)
                }
            }
            Text(" = Expenses")
        }
    }
}
//To fetch the current date in yyyy-mm-dd format
fun FetchCurrentDate(): String {
    val format = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
    return format.format(Date())
}

//To fetch the current month only in mmmm format

fun FetchCurrentMonth(): String {
    val format = SimpleDateFormat("MMMM", Locale.getDefault())
    return format.format(Date())
}

//To fetch the current year only in yyyy format

fun FetchCurrentYear(): Int {
    val format = SimpleDateFormat("yyyy", Locale.getDefault())
    return format.format(Date()).toInt()
}